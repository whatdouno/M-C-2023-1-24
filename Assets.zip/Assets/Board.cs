using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board : MonoBehaviour
{
    public GameObject[] tiles; //
    
       
     
    // Start is called before the first frame update
    void Start()
    {
        //Debug.Log(TilesList[0])
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
